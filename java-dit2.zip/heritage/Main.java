public class Main
{
    public static void main(String[] args)
    {
        Point p = new Point(3, 4);
        PointColore pc = new PointColore(2, 5, "BLEU");

        System.out.println("Point        : " + p);
        System.out.println("Point coloré : " + pc);
    }
}