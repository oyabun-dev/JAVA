public class Animal
{
	protected String nom;

	public Animal(String nom)
	{
		this.nom = nom;
	}

	public void deplacer()
	{
		System.out.println("Je me déplace comme un animal Lambda");
	}
}