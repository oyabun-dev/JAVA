public interface FigureGeometrique
{
	public double perimetre();
	public double surface();
}