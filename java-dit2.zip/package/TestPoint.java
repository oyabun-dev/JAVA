package bin;

import geo.Point;

public class TestPoint
{
	public static void main(String[] args)
	{	
		Point p = new Point(2, 6);

		System.out.println(p);
	}
}